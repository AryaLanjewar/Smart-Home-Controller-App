import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
} from "./components/ui/card";
import { Switch } from "./components/ui/switch";
import { Slider } from "./components/ui/slider";
import { Button } from "./components/ui/button";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./components/ui/tabs";
import { Badge } from "./components/ui/badge";
import {
  Fan,
  AirVent,
  Tv,
  Lightbulb,
  Plus,
  Minus,
  Power,
  Home,
  Settings,
  Palette,
  Grid3X3,
  List,
  Layout,
} from "lucide-react";

interface ApplianceState {
  fan: {
    isOn: boolean;
    speed: number;
  };
  ac: {
    isOn: boolean;
    temperature: number;
  };
  tv: {
    isOn: boolean;
    volume: number;
    channel: number;
  };
  lights: {
    isOn: boolean;
    brightness: number;
    color: string;
  };
}

const colorOptions = [
  "#FFFFFF",
  "#FFE4B5",
  "#FFB6C1",
  "#98FB98",
  "#87CEEB",
  "#DDA0DD",
  "#F0E68C",
  "#FFA07A",
];

type DesignVariant = "cards" | "grid" | "tabs";

export default function App() {
  const [appliances, setAppliances] = useState<ApplianceState>({
    fan: { isOn: false, speed: 3 },
    ac: { isOn: false, temperature: 22 },
    tv: { isOn: false, volume: 15, channel: 1 },
    lights: { isOn: false, brightness: 50, color: "#FFFFFF" },
  });

  const [currentDesign, setCurrentDesign] =
    useState<DesignVariant>("cards");

  const updateAppliance = (
    appliance: keyof ApplianceState,
    updates: Partial<ApplianceState[keyof ApplianceState]>,
  ) => {
    setAppliances((prev) => ({
      ...prev,
      [appliance]: { ...prev[appliance], ...updates },
    }));
  };

  const activeDevices = Object.values(appliances).filter(
    (device) => device.isOn,
  ).length;

  // Design A: Card-based Layout
  const CardDesign = () => (
    <div className="space-y-4">
      {/* Fan Control */}
      <Card className="shadow-lg border-0 transition-all duration-300 hover:shadow-xl">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-full transition-all duration-300 ${appliances.fan.isOn ? "bg-primary scale-110" : "bg-muted"}`}
              >
                <Fan
                  className={`w-5 h-5 transition-colors duration-300 ${appliances.fan.isOn ? "text-primary-foreground animate-spin" : "text-muted-foreground"}`}
                />
              </div>
              <div>
                <h3 className="font-medium">Ceiling Fan</h3>
                <p className="text-sm text-muted-foreground">
                  Living Room
                </p>
              </div>
            </div>
            <Switch
              checked={appliances.fan.isOn}
              onCheckedChange={(isOn) =>
                updateAppliance("fan", { isOn })
              }
            />
          </div>
        </CardHeader>
        {appliances.fan.isOn && (
          <CardContent className="pt-0 animate-in slide-in-from-top-2 duration-300">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Speed</span>
                <Badge variant="secondary">
                  {appliances.fan.speed}
                </Badge>
              </div>
              <Slider
                value={[appliances.fan.speed]}
                onValueChange={([speed]) =>
                  updateAppliance("fan", { speed })
                }
                max={5}
                min={1}
                step={1}
                className="w-full"
              />
            </div>
          </CardContent>
        )}
      </Card>

      {/* Air Conditioner Control */}
      <Card className="shadow-lg border-0 transition-all duration-300 hover:shadow-xl">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-full transition-all duration-300 ${appliances.ac.isOn ? "bg-primary scale-110" : "bg-muted"}`}
              >
                <AirVent
                  className={`w-5 h-5 transition-colors duration-300 ${appliances.ac.isOn ? "text-primary-foreground" : "text-muted-foreground"}`}
                />
              </div>
              <div>
                <h3 className="font-medium">Air Conditioner</h3>
                <p className="text-sm text-muted-foreground">
                  Living Room
                </p>
              </div>
            </div>
            <Switch
              checked={appliances.ac.isOn}
              onCheckedChange={(isOn) =>
                updateAppliance("ac", { isOn })
              }
            />
          </div>
        </CardHeader>
        {appliances.ac.isOn && (
          <CardContent className="pt-0 animate-in slide-in-from-top-2 duration-300">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Temperature</span>
                <Badge variant="secondary">
                  {appliances.ac.temperature}°C
                </Badge>
              </div>
              <Slider
                value={[appliances.ac.temperature]}
                onValueChange={([temperature]) =>
                  updateAppliance("ac", { temperature })
                }
                max={30}
                min={16}
                step={1}
                className="w-full"
              />
              <div className="flex items-center justify-center gap-4 mt-4">
                <Button
                  variant="outline"
                  size="sm"
                  className="transition-all duration-200 hover:scale-105"
                  onClick={() =>
                    updateAppliance("ac", {
                      temperature: Math.max(
                        16,
                        appliances.ac.temperature - 1,
                      ),
                    })
                  }
                >
                  <Minus className="w-4 h-4" />
                </Button>
                <span className="text-lg font-semibold w-16 text-center">
                  {appliances.ac.temperature}°C
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  className="transition-all duration-200 hover:scale-105"
                  onClick={() =>
                    updateAppliance("ac", {
                      temperature: Math.min(
                        30,
                        appliances.ac.temperature + 1,
                      ),
                    })
                  }
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Television Control */}
      <Card className="shadow-lg border-0 transition-all duration-300 hover:shadow-xl">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-full transition-all duration-300 ${appliances.tv.isOn ? "bg-primary scale-110" : "bg-muted"}`}
              >
                <Tv
                  className={`w-5 h-5 transition-colors duration-300 ${appliances.tv.isOn ? "text-primary-foreground" : "text-muted-foreground"}`}
                />
              </div>
              <div>
                <h3 className="font-medium">Smart TV</h3>
                <p className="text-sm text-muted-foreground">
                  Living Room
                </p>
              </div>
            </div>
            <Switch
              checked={appliances.tv.isOn}
              onCheckedChange={(isOn) =>
                updateAppliance("tv", { isOn })
              }
            />
          </div>
        </CardHeader>
        {appliances.tv.isOn && (
          <CardContent className="pt-0 animate-in slide-in-from-top-2 duration-300">
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Volume</span>
                  <Badge variant="secondary">
                    {appliances.tv.volume}
                  </Badge>
                </div>
                <Slider
                  value={[appliances.tv.volume]}
                  onValueChange={([volume]) =>
                    updateAppliance("tv", { volume })
                  }
                  max={100}
                  min={0}
                  step={1}
                  className="w-full"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">Channel</span>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="transition-all duration-200 hover:scale-105"
                    onClick={() =>
                      updateAppliance("tv", {
                        channel: Math.max(
                          1,
                          appliances.tv.channel - 1,
                        ),
                      })
                    }
                  >
                    <Minus className="w-3 h-3" />
                  </Button>
                  <Badge
                    variant="outline"
                    className="w-8 text-center"
                  >
                    {appliances.tv.channel}
                  </Badge>
                  <Button
                    variant="outline"
                    size="sm"
                    className="transition-all duration-200 hover:scale-105"
                    onClick={() =>
                      updateAppliance("tv", {
                        channel: appliances.tv.channel + 1,
                      })
                    }
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        )}
      </Card>

      {/* Lights Control */}
      <Card className="shadow-lg border-0 transition-all duration-300 hover:shadow-xl">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`p-2 rounded-full transition-all duration-300 ${appliances.lights.isOn ? "bg-primary scale-110" : "bg-muted"}`}
              >
                <Lightbulb
                  className={`w-5 h-5 transition-colors duration-300 ${appliances.lights.isOn ? "text-primary-foreground" : "text-muted-foreground"}`}
                />
              </div>
              <div>
                <h3 className="font-medium">Smart Lights</h3>
                <p className="text-sm text-muted-foreground">
                  Living Room
                </p>
              </div>
            </div>
            <Switch
              checked={appliances.lights.isOn}
              onCheckedChange={(isOn) =>
                updateAppliance("lights", { isOn })
              }
            />
          </div>
        </CardHeader>
        {appliances.lights.isOn && (
          <CardContent className="pt-0 animate-in slide-in-from-top-2 duration-300">
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Brightness</span>
                  <Badge variant="secondary">
                    {appliances.lights.brightness}%
                  </Badge>
                </div>
                <Slider
                  value={[appliances.lights.brightness]}
                  onValueChange={([brightness]) =>
                    updateAppliance("lights", { brightness })
                  }
                  max={100}
                  min={0}
                  step={1}
                  className="w-full"
                />
              </div>
              <div className="space-y-2">
                <span className="text-sm">Color</span>
                <div className="grid grid-cols-4 gap-2">
                  {colorOptions.map((color) => (
                    <button
                      key={color}
                      onClick={() =>
                        updateAppliance("lights", { color })
                      }
                      className={`w-full h-8 rounded-md border-2 transition-all duration-200 hover:scale-105 ${
                        appliances.lights.color === color
                          ? "border-primary scale-105 shadow-md"
                          : "border-border"
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );

  // Design B: Grid-based Compact Layout
  const GridDesign = () => (
    <div className="grid grid-cols-2 gap-4">
      {/* Fan Control */}
      <Card className="shadow-lg border-0 transition-all duration-300 hover:shadow-xl hover:scale-105">
        <CardContent className="p-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div
                className={`p-2 rounded-full ${appliances.fan.isOn ? "bg-primary" : "bg-muted"}`}
              >
                <Fan
                  className={`w-4 h-4 ${appliances.fan.isOn ? "text-primary-foreground animate-spin" : "text-muted-foreground"}`}
                />
              </div>
              <Switch
                checked={appliances.fan.isOn}
                onCheckedChange={(isOn) =>
                  updateAppliance("fan", { isOn })
                }
                className="scale-75"
              />
            </div>
            <div>
              <h4 className="font-medium text-sm">Fan</h4>
              <p className="text-xs text-muted-foreground">
                Speed: {appliances.fan.speed}
              </p>
            </div>
            {appliances.fan.isOn && (
              <Slider
                value={[appliances.fan.speed]}
                onValueChange={([speed]) =>
                  updateAppliance("fan", { speed })
                }
                max={5}
                min={1}
                step={1}
                className="w-full"
              />
            )}
          </div>
        </CardContent>
      </Card>

      {/* AC Control */}
      <Card className="shadow-lg border-0 transition-all duration-300 hover:shadow-xl hover:scale-105">
        <CardContent className="p-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div
                className={`p-2 rounded-full ${appliances.ac.isOn ? "bg-primary" : "bg-muted"}`}
              >
                <AirVent
                  className={`w-4 h-4 ${appliances.ac.isOn ? "text-primary-foreground" : "text-muted-foreground"}`}
                />
              </div>
              <Switch
                checked={appliances.ac.isOn}
                onCheckedChange={(isOn) =>
                  updateAppliance("ac", { isOn })
                }
                className="scale-75"
              />
            </div>
            <div>
              <h4 className="font-medium text-sm">AC</h4>
              <p className="text-xs text-muted-foreground">
                {appliances.ac.temperature}°C
              </p>
            </div>
            {appliances.ac.isOn && (
              <div className="space-y-2">
                <Slider
                  value={[appliances.ac.temperature]}
                  onValueChange={([temperature]) =>
                    updateAppliance("ac", { temperature })
                  }
                  max={30}
                  min={16}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() =>
                      updateAppliance("ac", {
                        temperature: Math.max(
                          16,
                          appliances.ac.temperature - 1,
                        ),
                      })
                    }
                  >
                    <Minus className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() =>
                      updateAppliance("ac", {
                        temperature: Math.min(
                          30,
                          appliances.ac.temperature + 1,
                        ),
                      })
                    }
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* TV Control */}
      <Card className="shadow-lg border-0 transition-all duration-300 hover:shadow-xl hover:scale-105">
        <CardContent className="p-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div
                className={`p-2 rounded-full ${appliances.tv.isOn ? "bg-primary" : "bg-muted"}`}
              >
                <Tv
                  className={`w-4 h-4 ${appliances.tv.isOn ? "text-primary-foreground" : "text-muted-foreground"}`}
                />
              </div>
              <Switch
                checked={appliances.tv.isOn}
                onCheckedChange={(isOn) =>
                  updateAppliance("tv", { isOn })
                }
                className="scale-75"
              />
            </div>
            <div>
              <h4 className="font-medium text-sm">TV</h4>
              <p className="text-xs text-muted-foreground">
                Ch {appliances.tv.channel} • Vol{" "}
                {appliances.tv.volume}
              </p>
            </div>
            {appliances.tv.isOn && (
              <div className="space-y-2">
                <Slider
                  value={[appliances.tv.volume]}
                  onValueChange={([volume]) =>
                    updateAppliance("tv", { volume })
                  }
                  max={100}
                  min={0}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-center gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() =>
                      updateAppliance("tv", {
                        channel: Math.max(
                          1,
                          appliances.tv.channel - 1,
                        ),
                      })
                    }
                  >
                    <Minus className="w-3 h-3" />
                  </Button>
                  <span className="text-xs font-medium px-2 py-1 bg-muted rounded">
                    {appliances.tv.channel}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() =>
                      updateAppliance("tv", {
                        channel: appliances.tv.channel + 1,
                      })
                    }
                  >
                    <Plus className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Lights Control */}
      <Card className="shadow-lg border-0 transition-all duration-300 hover:shadow-xl hover:scale-105">
        <CardContent className="p-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div
                className={`p-2 rounded-full ${appliances.lights.isOn ? "bg-primary" : "bg-muted"}`}
              >
                <Lightbulb
                  className={`w-4 h-4 ${appliances.lights.isOn ? "text-primary-foreground" : "text-muted-foreground"}`}
                />
              </div>
              <Switch
                checked={appliances.lights.isOn}
                onCheckedChange={(isOn) =>
                  updateAppliance("lights", { isOn })
                }
                className="scale-75"
              />
            </div>
            <div>
              <h4 className="font-medium text-sm">Lights</h4>
              <p className="text-xs text-muted-foreground">
                {appliances.lights.brightness}%
              </p>
            </div>
            {appliances.lights.isOn && (
              <div className="space-y-2">
                <Slider
                  value={[appliances.lights.brightness]}
                  onValueChange={([brightness]) =>
                    updateAppliance("lights", { brightness })
                  }
                  max={100}
                  min={0}
                  step={1}
                  className="w-full"
                />
                <div className="grid grid-cols-4 gap-1">
                  {colorOptions.slice(0, 4).map((color) => (
                    <button
                      key={color}
                      onClick={() =>
                        updateAppliance("lights", { color })
                      }
                      className={`w-full h-4 rounded border transition-all duration-200 hover:scale-105 ${
                        appliances.lights.color === color
                          ? "border-primary scale-105"
                          : "border-border"
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // Design C: Tab-based Layout
  const TabDesign = () => (
    <Tabs defaultValue="climate" className="w-full">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger
          value="climate"
          className="flex items-center gap-2"
        >
          <AirVent className="w-4 h-4" />
          Climate
        </TabsTrigger>
        <TabsTrigger
          value="entertainment"
          className="flex items-center gap-2"
        >
          <Tv className="w-4 h-4" />
          Media
        </TabsTrigger>
        <TabsTrigger
          value="lighting"
          className="flex items-center gap-2"
        >
          <Lightbulb className="w-4 h-4" />
          Lights
        </TabsTrigger>
      </TabsList>

      <TabsContent value="climate" className="space-y-4 mt-6">
        {/* Fan Control */}
        <Card className="shadow-lg border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <div
                  className={`p-3 rounded-full ${appliances.fan.isOn ? "bg-primary" : "bg-muted"}`}
                >
                  <Fan
                    className={`w-6 h-6 ${appliances.fan.isOn ? "text-primary-foreground animate-spin" : "text-muted-foreground"}`}
                  />
                </div>
                <div>
                  <h3 className="font-semibold">Ceiling Fan</h3>
                  <p className="text-sm text-muted-foreground">
                    Living Room • Speed {appliances.fan.speed}
                  </p>
                </div>
              </div>
              <Switch
                checked={appliances.fan.isOn}
                onCheckedChange={(isOn) =>
                  updateAppliance("fan", { isOn })
                }
              />
            </div>
            {appliances.fan.isOn && (
              <div className="space-y-4">
                <Slider
                  value={[appliances.fan.speed]}
                  onValueChange={([speed]) =>
                    updateAppliance("fan", { speed })
                  }
                  max={5}
                  min={1}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Low</span>
                  <span>Medium</span>
                  <span>High</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* AC Control */}
        <Card className="shadow-lg border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <div
                  className={`p-3 rounded-full ${appliances.ac.isOn ? "bg-primary" : "bg-muted"}`}
                >
                  <AirVent
                    className={`w-6 h-6 ${appliances.ac.isOn ? "text-primary-foreground" : "text-muted-foreground"}`}
                  />
                </div>
                <div>
                  <h3 className="font-semibold">
                    Air Conditioner
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Living Room • {appliances.ac.temperature}°C
                  </p>
                </div>
              </div>
              <Switch
                checked={appliances.ac.isOn}
                onCheckedChange={(isOn) =>
                  updateAppliance("ac", { isOn })
                }
              />
            </div>
            {appliances.ac.isOn && (
              <div className="space-y-4">
                <div className="text-center">
                  <span className="text-3xl font-bold text-primary">
                    {appliances.ac.temperature}°C
                  </span>
                </div>
                <Slider
                  value={[appliances.ac.temperature]}
                  onValueChange={([temperature]) =>
                    updateAppliance("ac", { temperature })
                  }
                  max={30}
                  min={16}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>16°C</span>
                  <span>23°C</span>
                  <span>30°C</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent
        value="entertainment"
        className="space-y-4 mt-6"
      >
        <Card className="shadow-lg border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <div
                  className={`p-3 rounded-full ${appliances.tv.isOn ? "bg-primary" : "bg-muted"}`}
                >
                  <Tv
                    className={`w-6 h-6 ${appliances.tv.isOn ? "text-primary-foreground" : "text-muted-foreground"}`}
                  />
                </div>
                <div>
                  <h3 className="font-semibold">Smart TV</h3>
                  <p className="text-sm text-muted-foreground">
                    Living Room • Channel{" "}
                    {appliances.tv.channel}
                  </p>
                </div>
              </div>
              <Switch
                checked={appliances.tv.isOn}
                onCheckedChange={(isOn) =>
                  updateAppliance("tv", { isOn })
                }
              />
            </div>
            {appliances.tv.isOn && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">
                      Volume
                    </span>
                    <Badge variant="secondary">
                      {appliances.tv.volume}
                    </Badge>
                  </div>
                  <Slider
                    value={[appliances.tv.volume]}
                    onValueChange={([volume]) =>
                      updateAppliance("tv", { volume })
                    }
                    max={100}
                    min={0}
                    step={1}
                    className="w-full"
                  />
                </div>
                <div className="space-y-2">
                  <span className="text-sm font-medium">
                    Channel
                  </span>
                  <div className="flex items-center justify-center gap-4">
                    <Button
                      variant="outline"
                      onClick={() =>
                        updateAppliance("tv", {
                          channel: Math.max(
                            1,
                            appliances.tv.channel - 1,
                          ),
                        })
                      }
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="text-xl font-semibold w-16 text-center">
                      {appliances.tv.channel}
                    </span>
                    <Button
                      variant="outline"
                      onClick={() =>
                        updateAppliance("tv", {
                          channel: appliances.tv.channel + 1,
                        })
                      }
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="lighting" className="space-y-4 mt-6">
        <Card className="shadow-lg border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <div
                  className={`p-3 rounded-full ${appliances.lights.isOn ? "bg-primary" : "bg-muted"}`}
                >
                  <Lightbulb
                    className={`w-6 h-6 ${appliances.lights.isOn ? "text-primary-foreground" : "text-muted-foreground"}`}
                  />
                </div>
                <div>
                  <h3 className="font-semibold">
                    Smart Lights
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Living Room • {appliances.lights.brightness}
                    %
                  </p>
                </div>
              </div>
              <Switch
                checked={appliances.lights.isOn}
                onCheckedChange={(isOn) =>
                  updateAppliance("lights", { isOn })
                }
              />
            </div>
            {appliances.lights.isOn && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">
                      Brightness
                    </span>
                    <Badge variant="secondary">
                      {appliances.lights.brightness}%
                    </Badge>
                  </div>
                  <Slider
                    value={[appliances.lights.brightness]}
                    onValueChange={([brightness]) =>
                      updateAppliance("lights", { brightness })
                    }
                    max={100}
                    min={0}
                    step={1}
                    className="w-full"
                  />
                </div>
                <div className="space-y-3">
                  <span className="text-sm font-medium">
                    Color Temperature
                  </span>
                  <div className="grid grid-cols-4 gap-3">
                    {colorOptions.map((color) => (
                      <button
                        key={color}
                        onClick={() =>
                          updateAppliance("lights", { color })
                        }
                        className={`w-full h-12 rounded-lg border-2 transition-all duration-200 hover:scale-105 ${
                          appliances.lights.color === color
                            ? "border-primary scale-105 shadow-lg"
                            : "border-border"
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );

  const renderCurrentDesign = () => {
    switch (currentDesign) {
      case "cards":
        return <CardDesign />;
      case "grid":
        return <GridDesign />;
      case "tabs":
        return <TabDesign />;
      default:
        return <CardDesign />;
    }
  };

  return (
    <div className="min-h-screen bg-background px-4 py-6">
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-2xl font-semibold text-foreground">
              Smart Home
            </h1>
            <Badge
              variant="outline"
              className="flex items-center gap-1"
            >
              <Power className="w-3 h-3" />
              {activeDevices} active
            </Badge>
          </div>
          <p className="text-muted-foreground">
            Control your home appliances
          </p>
        </div>

        {/* Design Switcher */}
        <div className="mb-6">
          <div className="flex items-center gap-2 p-1 bg-muted rounded-lg">
            <Button
              variant={
                currentDesign === "cards" ? "default" : "ghost"
              }
              size="sm"
              onClick={() => setCurrentDesign("cards")}
              className="flex-1 gap-2 transition-all duration-200"
            >
              <List className="w-4 h-4" />
              Cards
            </Button>
            <Button
              variant={
                currentDesign === "grid" ? "default" : "ghost"
              }
              size="sm"
              onClick={() => setCurrentDesign("grid")}
              className="flex-1 gap-2 transition-all duration-200"
            >
              <Grid3X3 className="w-4 h-4" />
              Grid
            </Button>
            <Button
              variant={
                currentDesign === "tabs" ? "default" : "ghost"
              }
              size="sm"
              onClick={() => setCurrentDesign("tabs")}
              className="flex-1 gap-2 transition-all duration-200"
            >
              <Layout className="w-4 h-4" />
              Tabs
            </Button>
          </div>
        </div>

        {/* Current Design */}
        <div className="transition-all duration-500 ease-in-out">
          {renderCurrentDesign()}
        </div>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-xs text-muted-foreground">
            Smart Home Controller v1.0 • Design{" "}
            {currentDesign.charAt(0).toUpperCase() +
              currentDesign.slice(1)}
          </p>
        </div>
      </div>
    </div>
  );
}